//package com.example.demo.dao;
//
//import java.util.List;
//
//import org.springframework.stereotype.Repository;
//
//import com.example.demo.entity.Employee;
//
//
//import jakarta.persistence.EntityManager;
//import jakarta.persistence.PersistenceContext;
//import jakarta.persistence.TypedQuery;
//
//@Repository
//public class EmployeeDaoImpl implements EmployeeDao{
//
//	@PersistenceContext
//	EntityManager entityManager;
//	
//	@Override
//	public String addEmployees(Employee employee) {
//		// TODO Auto-generated method stub
//		entityManager.persist(employee);
//		return "Employee Saved Successfully";
//	}
//
//	@Override
//	public String UpdateEmployee(Employee employee) {
//		// TODO Auto-generated method stub
//		entityManager.merge(employee);
//		return "Employee Updated Successfully";
//	}
//
//	@Override
//	public String deleteEmployee(int empid) {
//		// TODO Auto-generated method stub
//		entityManager.remove(getEmployeeByID(empid));
//		return " Employee Delete Successfully";
//	}
//
//	@Override
//	public Employee getEmployeeByID(int empid) {
//		// TODO Auto-generated method stub
//		return entityManager.find(Employee.class, empid);
//	}
//
//	@Override
//	public List<Employee> getAllEmployees() {
//		// TODO Auto-generated method stub
//		TypedQuery<Employee> products=entityManager.createQuery("select p from Employee p",Employee.class);
//		return products.getResultList();
//	}
//
//	@Override
//	public List<Employee> getAllEmployeesBetweenSalary(int intialSal, int finalSal) {
//		// TODO Auto-generated method stub
//		TypedQuery<Employee> products=entityManager.createQuery
//				("select p from Product p where p.empsal between ?1 and ?2",Employee.class);
//		products.setParameter(1,intialSal);
//		products.setParameter(2,finalSal);
//		return products.getResultList();
//	}
//
//	@Override
//	public List<Employee> getAllEmployeesByDesgination(String Designation) {
//		// TODO Auto-generated method stub
//		TypedQuery<Employee> products=entityManager.createQuery("select p from Product p where p.empdesc==?1",Employee.class);
//		products.setParameter(1,Designation);
//		return products.getResultList();
//	}
//
//}
