package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;


@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired 
	EmployeeService service;
	
	@PostMapping("/addemployee")
	public String addProducts(@RequestBody Employee employee) {
		return service.addEmployees(employee);
	}
	
	@PutMapping("/updateemployee")
	 public String UpdateProduct(Employee employee) {
		 return service.UpdateEmployee(employee);
	 }
	
	@DeleteMapping("/deleteemployee")
	 public String deleteProduct(int empid)
	 {
		 return service.deleteEmployee(empid);
	 }
	
	@GetMapping("/getemployeetbyid/{id}")
	 public Employee getProductByID(@PathVariable("id") int empid)
	 {
		 return service.getEmployeeByID(empid);
	 }
	
	@GetMapping("/getallemployees")
	 public List<Employee> getAllProducts()
	 {
		 return service.getAllEmployees();
	 }
	
	@GetMapping("/getallemployeesbtwsalary/{iprice}/{fprice}")
	 public List<Employee> getAllProductsBetweenPrices(@PathVariable("iprice")int intialSal,@PathVariable("fprice")int finalSal) {
		 return service.getAllEmployeesBetweenSalary(intialSal, finalSal);
	 }
	
	@GetMapping("/getallemployeesbydesc{pc}")
	 public List<Employee> getAllProductsByCategory(@PathVariable("pc")String empdesc)
	 {
		 return service.getAllEmployeesByDesgination(empdesc);
	 }

}
