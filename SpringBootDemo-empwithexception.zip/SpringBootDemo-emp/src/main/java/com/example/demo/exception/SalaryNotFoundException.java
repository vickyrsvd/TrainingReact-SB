package com.example.demo.exception;

public class SalaryNotFoundException extends Exception {

	public SalaryNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
