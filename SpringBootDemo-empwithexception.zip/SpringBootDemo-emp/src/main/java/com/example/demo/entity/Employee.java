package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="employee_info")
public class Employee {

	@Id
	@GeneratedValue
	@Column(name="eid")
	private int empid;
	@Size(min=6,max=15,message="Employee Name should be in the range of(6,15)")
	@NotEmpty(message="Employee name cannot be empty or null")
	private String empname;
	@Min(value=1000,message="Employee salary should be greater than 1000")
	@Max(value=1000000 ,message="Employee salary cannot be above 1000000....")
	private float empsal;
	private String empdesc;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int empid, String empname, float empsal, String empdesc) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsal = empsal;
		this.empdesc = empdesc;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public float getEmpsal() {
		return empsal;
	}
	public void setEmpsal(float empsal) {
		this.empsal = empsal;
	}
	public String getEmpdesc() {
		return empdesc;
	}
	public void setEmpdesc(String empdesc) {
		this.empdesc = empdesc;
	}
	
	
}
