package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeDao {

	abstract String addEmployees(Employee employee);
	 abstract String UpdateEmployee(Employee employee);
	 abstract String deleteEmployee(int empid);
	 abstract Employee getEmployeeByID(int empid);
	 abstract List<Employee> getAllEmployees();
	 abstract List<Employee> getAllEmployeesBetweenSalary(int intialSal,int finalSal);
	 abstract List<Employee> getAllEmployeesByDesgination(String Designation);
}
