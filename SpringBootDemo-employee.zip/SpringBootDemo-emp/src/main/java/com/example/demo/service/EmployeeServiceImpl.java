package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao empdao;
	
	@Override
	public String addEmployees(Employee employee) {
		// TODO Auto-generated method stub
		return empdao.addEmployees(employee);
	}

	@Override
	public String UpdateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return empdao.UpdateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int empid) {
		// TODO Auto-generated method stub
		return empdao.deleteEmployee(empid);
	}

	@Override
	public Employee getEmployeeByID(int empid) {
		// TODO Auto-generated method stub
		return empdao.getEmployeeByID(empid);
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empdao.getAllEmployees();
	}

	@Override
	public List<Employee> getAllEmployeesBetweenSalary(int intialSal, int finalSal) {
		// TODO Auto-generated method stub
		return empdao.getAllEmployeesBetweenSalary(intialSal, finalSal);
	}

	@Override
	public List<Employee> getAllEmployeesByDesgination(String Designation) {
		// TODO Auto-generated method stub
		return empdao.getAllEmployeesByDesgination(Designation);
	}

}
